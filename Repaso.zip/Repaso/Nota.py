nota = int(input("Ingresa tu nota (0-10): \n"))

if nota<5:
    print("Reprobaste")
elif nota>=5 and nota<10:
    print("Aprobaste")
elif nota==10:
    print("Sobresaliente")
else:
    print("Nota no valida")