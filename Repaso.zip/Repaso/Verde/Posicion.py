numeros = [1,2,3,5,6,7]

buscado = int(input("Ingrese el numero a buscar: \n"))

if buscado in numeros:
    posicion = numeros.index(buscado)
    print(f"Numero {buscado} encontrado en la posicion {posicion}")
else:
    print("El numero no se encuentra en la lista")