numeros = [1,2,3,4,5,6,7]

num = int(input("Numero que desea insertar: \n"))
posicion = int(input("Ingrese el numero de la posicion: \n"))

numeros.insert(posicion, num)
print("Lista actualizada: ",numeros)