nombres = ["Sofia","Laura","Dayana"]
edades = [18,27,15]

combinacion= nombres + edades

print("Lista combinada: \n",combinacion)