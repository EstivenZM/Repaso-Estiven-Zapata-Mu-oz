nombres = []

for i in range(3):
    ingresar = input("Ingresa nombre: \n")
    nombres.append(ingresar)

print("Lista de los nombres: \n",nombres)