nombre= ["Sofia","Ana","Laura","Sofia"]

encontrado = input("Ingrese un nombre: \n")

contador = nombre.count(encontrado)
print(f"El nombre {encontrado} aparece {contador} veces en la lista")