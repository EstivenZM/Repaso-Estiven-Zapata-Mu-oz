numeros = [1,3,5,7,2,4]
print("Lista de numeros desordenados: \n",numeros)
numeros.sort()
print("Numeros ordenados: \n",numeros)