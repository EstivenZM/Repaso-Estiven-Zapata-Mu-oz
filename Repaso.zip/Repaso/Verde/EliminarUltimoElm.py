frutas = ["piña","naranja","manzana"]
print ("Lista de frutas: ",frutas)

elemento = frutas.pop()
print("Se eliminó el elemento ",elemento)
print("lista actualizada: \n",frutas)