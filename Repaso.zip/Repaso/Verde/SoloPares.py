pares = []
impares = []

for i in range(5):
    num = int(input("Ingrese numero: \n"))
    if num%2==0:
        pares.append(num)
    else:
        impares.append(num)

print("Numeros pares: \n",pares)
print("Numeros impares: \n",impares)