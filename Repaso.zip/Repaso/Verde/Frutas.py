frutas = ["piña","naranja","manzana"]
print("Lista de frutas: \n",frutas)
eliminar = input("Que fruta deseas eliminar: \n")

if eliminar in frutas:
    frutas.remove(eliminar)
else:
    print("Esta fruta no se encuentra en la lista")

print ("Lista de frutas actualizada: \n", frutas)