palabras = ["hola","sofia","arbol","cuaderno","zara"]
print("Lista de palabras desordenadas: \n",palabras)

palabras.sort()
print("Lista ordenada: \n",palabras)

palabras.reverse()
print("Lista al revez: \n",palabras)