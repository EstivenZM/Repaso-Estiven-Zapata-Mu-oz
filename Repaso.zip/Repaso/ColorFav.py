color = input("Ingrese su colo favorito: \n")

if color != "rojo":
    print("Ese no es el color que esperaba")
else:
    print("Respuesta correcta")