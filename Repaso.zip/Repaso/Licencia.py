licencia = input("Tienes licencia? (si o no): \n")
casco = input("Tienes casco? (si o no): \n")

if licencia=="no" or casco=="no":
    print("No puedes conducir")
else:
    print("Puedes conducir")