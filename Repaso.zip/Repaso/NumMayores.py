num1= float(input("Ingresa un numero: \n"))
num2= float(input("Ingresa un 2do numero: \n"))

if num1>0 and num2>0:
    print("Ambos son positivos")
else:
    print("Los dos no son positivos")