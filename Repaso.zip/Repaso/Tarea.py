pregunta = input("Terminaste tu tarea? (si o no): \n")

if pregunta!="si":
    print("Debes terminar la tarea")
else:
    print("Felicidades")