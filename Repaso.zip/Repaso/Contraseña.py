clave = int(input("Ingrese la contraseña: \n"))

if clave == 1234:
    print("Bienvenido al sistema")
else:
    print("Contraseña incorrecta")