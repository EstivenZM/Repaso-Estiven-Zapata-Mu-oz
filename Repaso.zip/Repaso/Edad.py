edad = int(input("Ingrese su edad: \n"))

if edad>=18:
    print("Puedes votar")
else:
    print("No puedes votar")