temperatura = int(input("Ingresa una temperatura: \n"))

if temperatura < 0:
    print("Hace frío")
else:
    print("Hace calor")